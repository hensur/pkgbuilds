#!/bin/bash

# This script is executed after Homegear is stopped. Execute clean-up or backup commands here.
